version = 1
cloudstream {
    language = "es"
    authors = listOf("Javier")

    status = 1
    tvTypes = listOf(
        "Anime"
    )
}